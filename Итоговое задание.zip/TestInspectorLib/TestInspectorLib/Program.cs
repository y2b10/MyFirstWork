﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InspectorLib;

namespace TestInspectorLib
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            FunctionInsp инспектор = new FunctionInsp();

            Console.WriteLine($"Начальник: {инспектор.GetInspector()}");
            Console.WriteLine($"Название отдела: {инспектор.GetCarInspection()}");

  

            string номернойЗнак = инспектор.GenerateNumber(123, 'X');
            Console.WriteLine($"Сгенерированный номер: {номернойЗнак}");

            List<string> сотрудники = инспектор.GetWorker();
            Console.WriteLine("Список сотрудников:");
            foreach (string сотрудник in сотрудники)
            {
                Console.WriteLine(сотрудник);
            }

            }

            
        }
    }
