﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectorLib
{
    public class FunctionInsp
    {
        private string _названиеОтдела = "Автоинспекция г. Чита";
        private string _начальник = "Васильев Василий Иванович";
        private List<string> _сотрудники = new List<string>() { "Иванов И.И.", "Зиронов Т.А.", "Миронов А.В.", "Васильев В.И." };
        private Random _random = new Random();

        public string GetInspector()
        {
            return _начальник;
        }

        public string GetCarInspection()
        {
            return _названиеОтдела;
        }

        public bool SetInspector(string fullName)
        {
            if (_сотрудники.Contains(fullName))
            {
                _начальник = fullName;
                return true;
            }
            return false;
        }

        public string GenerateNumber(int number, char symbol, int code = 75)
        {
            return $"{symbol.ToString().ToUpper()}{number}_{code}";
        }

        public List<string> GetWorker()
        {
            return _сотрудники;
        }

        public bool AddWorker(string fullName)
        {
            if (!_сотрудники.Contains(fullName))
            {
                _сотрудники.Add(fullName);
                return true;
            }
            return false;
        }
    }
}
