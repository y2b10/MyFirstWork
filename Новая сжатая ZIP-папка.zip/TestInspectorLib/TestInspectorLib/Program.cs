﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InspectorLib;

namespace TestInspectorLib
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            FunctionInsp инспектор = new FunctionInsp();

            Console.WriteLine($"Начальник: {инспектор.GetInspector()}");
            Console.WriteLine($"Название отдела: {инспектор.GetCarInspection()}");

            bool успех = инспектор.SetInspector("Зиронов Т.А.");
            Console.WriteLine($"Изменение начальника успешно: {успех}, Новый начальник: {инспектор.GetInspector()}");

            string номернойЗнак = инспектор.GenerateNumber(123, 'X');
            Console.WriteLine($"Сгенерированный номер: {номернойЗнак}");

            List<string> сотрудники = инспектор.GetWorker();
            Console.WriteLine("Список сотрудников:");
            foreach (string сотрудник in сотрудники)
            {
                Console.WriteLine(сотрудник);
            }

            успех = инспектор.AddWorker("Новиков Н.Н.");
            Console.WriteLine($"Добавление сотрудника успешно: {успех}");

            сотрудники = инспектор.GetWorker();
            Console.WriteLine("Обновлённый список сотрудников:");
            foreach (string сотрудник in сотрудники)
            {
                Console.WriteLine(сотрудник);
            }

            // Добавьте сюда больше тестов для проверки других сценариев и граничных случаев.
        }
    }
}
